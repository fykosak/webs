var i;

i = 10;
--i;
-- i;
-- /*comment*/ i;
++i;
++
   i;
++/*comment*/i;

i--;
i        --;
i /*comment*/ --;
i++;
i ++;
i /*comment*/ ++;
