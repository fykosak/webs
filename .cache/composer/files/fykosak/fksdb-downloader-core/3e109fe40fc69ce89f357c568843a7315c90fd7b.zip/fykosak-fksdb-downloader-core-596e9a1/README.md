# FKSDB Downloader Core

![FKSDB logo](https://github.com/fykosak/fksdb-downloader-core/blob/master/logo.svg?raw=true)
