<?php

declare(strict_types=1);

namespace Fykosak\Utils\Tests;

class DummyService
{

}
