<?php

declare(strict_types=1);

namespace PHPSTORM_META;

override(\Nette\Forms\Container::getValues(0), map(['' => '@|Nette\Utils\ArrayHash']));
override(new \Nette\Forms\Container, map(['' => 'Nette\Forms\Controls\BaseControl']));
