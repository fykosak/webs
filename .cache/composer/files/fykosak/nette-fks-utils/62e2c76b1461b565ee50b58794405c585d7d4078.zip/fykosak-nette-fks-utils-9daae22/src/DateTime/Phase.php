<?php

declare(strict_types=1);

namespace Fykosak\Utils\DateTime;

enum Phase
{
    case before;
    case after;
    case onGoing;
}
