<?php

/**
 * Rules for Nette Coding Standard
 * https://github.com/nette/coding-standard
 */

declare(strict_types=1);

return [
	// RobotLoader.php
	'Nette/statement_indentation' => false,
];
