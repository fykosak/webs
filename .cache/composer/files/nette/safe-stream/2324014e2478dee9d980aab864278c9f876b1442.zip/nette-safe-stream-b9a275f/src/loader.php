<?php

declare(strict_types=1);

Nette\SafeStream\Wrapper::register();
