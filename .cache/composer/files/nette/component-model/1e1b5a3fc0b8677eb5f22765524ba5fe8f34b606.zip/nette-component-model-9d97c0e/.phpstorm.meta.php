<?php

declare(strict_types=1);

namespace PHPSTORM_META;

override(\Nette\ComponentModel\Component::lookup(0), map(['' => '@']));
