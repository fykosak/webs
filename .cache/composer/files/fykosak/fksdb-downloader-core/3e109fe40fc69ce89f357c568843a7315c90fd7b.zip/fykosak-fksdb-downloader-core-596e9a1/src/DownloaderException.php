<?php

declare(strict_types=1);

namespace Fykosak\FKSDBDownloaderCore;

class DownloaderException extends \Exception
{
}
